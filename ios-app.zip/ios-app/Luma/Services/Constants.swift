import Foundation

let BASE_API_URL = "http://localhost:3000"
